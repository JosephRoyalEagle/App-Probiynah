<div class="content-header">
    <div class="header-left">
        <button class="menu-toggle" id="menuToggle">
            <i class="fas fa-bars"></i>
        </button>
        <h1 class="page-title"></h1>
    </div>
    <div class="user-info">
        <div class="user-cart-avatar"><i class="fas fa-cart-shopping"></i><span>3</span></div>
        <div class="service-client-avatar"><i class="fas fa-headset"></i></div>
        <div class="user-avatar"><i class="fas fa-user"></i></div>
        <div class="logout-avatar"> <a href="logout.php" class="text-white"><i class="fas fa-sign-out-alt"></i></a></div>
    </div>
</div>